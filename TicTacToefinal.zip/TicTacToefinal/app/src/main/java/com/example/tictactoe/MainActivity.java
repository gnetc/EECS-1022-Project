package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button buttonMain;
    private Button buttonCPU;
    MediaPlayer mySong;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mySong = MediaPlayer.create(MainActivity.this, R.raw.beat);

        buttonMain = (Button) findViewById(R.id.button);
        buttonCPU = (Button) findViewById(R.id.button2);


        buttonCPU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCPU = new Intent(MainActivity.this, MainGameCPU.class);
                startActivity(intentCPU);
            }
        });

        buttonMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, name.class);
                startActivity(intent);
            }
        });


    }

    public void playIT(View v) {
        mySong.start();

    }

}
